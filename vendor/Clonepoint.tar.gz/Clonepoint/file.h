#include <cstdio>
#include <cstdlib>

//This function is public domain, taken from https://gitorious.org/wikibooks-opengl
char* file_read(const char* filename, long* size_ret);
